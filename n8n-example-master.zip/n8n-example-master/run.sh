#!/bin/bash
n8n-node-dev build
n8n
